# syncAppMetadata deletes deployment records if needed

    Code
      syncAppMetadata(app)
    Message
      Deleting deployment record for deleted app 123.

