hello <- function() {
  print("Hello, world!")
}
